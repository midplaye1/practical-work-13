﻿using ConsoleApp0318.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page18.xaml
    /// </summary>
    public partial class Page18 : Page
    {
        public Page18()
        {
            InitializeComponent();
        }
        private void BtnTask18_Click(object sender, RoutedEventArgs e)
        {
            int[] array18 = { 10, 29, 32, 2, 1, 41, 5, 12, 3, 24 };
            int increasingSum = 0;
            int decreasingSum = 0;
            int n = array18.Length;
            if (n == 0) return;

            int currentSum = array18[0];
            bool isIncreasing = true;

            for (int i = 1; i < n; i++)
            {
                if (array18[i] > array18[i - 1])
                {
                    if (!isIncreasing)
                    {
                        decreasingSum += currentSum;
                        currentSum = 0;
                    }
                    isIncreasing = true;
                }
                else if (array18[i] < array18[i - 1])
                {
                    if (isIncreasing)
                    {
                        increasingSum += currentSum;
                        currentSum = 0;
                    }
                    isIncreasing = false;
                }

                currentSum += array18[i];
            }

            if (isIncreasing)
            {
                increasingSum += currentSum;
            }
            else
            {
                decreasingSum += currentSum;
            }
            MessageBox.Show($"Ответ =Разность между суммой возрастающих и убывающих участков: {increasingSum - decreasingSum}", "Системное сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
