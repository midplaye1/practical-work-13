﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page23.xaml
    /// </summary>
    public partial class Page23 : Page
    {
        public Page23()
        {
            InitializeComponent();
        }
        private void BtnTask23_Click(object sender, RoutedEventArgs e)
        {
            int[] array = { 101, 100, 10, 01, 001, 010 };
            int minIndex = 0;
            int maxIndex = 0;

            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] < array[minIndex])
                {
                    minIndex = i;
                }
                if (array[i] > array[maxIndex])
                {
                    maxIndex = i;
                }
            }

            int start = Math.Min(minIndex, maxIndex);
            int end = Math.Max(minIndex, maxIndex);
            int count = end - start - 1;

            if (count > 0)
            {
                MessageBox.Show($"Ответ =Количество чисел между минимальным и максимальным: {count}", "Системное сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Таких чисел нет", "Системное сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
