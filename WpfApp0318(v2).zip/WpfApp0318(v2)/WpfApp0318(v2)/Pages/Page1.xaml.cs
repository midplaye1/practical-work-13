﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page1.xaml
    /// </summary>
    public partial class Page1 : Page
    {
        public Page1()
        {
            InitializeComponent();
        }
        private void BtnTask1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string binaryInput = TextBoxBinaryNumber.Text;

                if (!IsBinary(binaryInput))
                {
                    MessageBox.Show("Ошибка: Введите двоичное число (состоящее только из 0 и 1).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                int decimalNumber = ConvertBinaryToDecimal(binaryInput);

                MessageBox.Show($"Двоичное число: {binaryInput}\nДесятичное представление: {decimalNumber}", "Результат", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool IsBinary(string binaryString)
        {
            foreach (char c in binaryString)
            {
                if (c != '0' && c != '1')
                    return false;
            }
            return true;
        }

        private int ConvertBinaryToDecimal(string binaryString)
        {
            int decimalNumber = 0;
            for (int i = 0; i < binaryString.Length; i++)
            {
                if (binaryString[binaryString.Length - 1 - i] == '1')
                {
                    decimalNumber += (1 << i);
                }
            }
            return decimalNumber;
        }
    }

}

