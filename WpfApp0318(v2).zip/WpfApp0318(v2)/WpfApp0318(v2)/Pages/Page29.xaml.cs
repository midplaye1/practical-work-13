﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page29.xaml
    /// </summary>
    public partial class Page29 : Page
    {
        public Page29()
        {
            InitializeComponent();
        }
        private void BtnTask29_Click(object sender, RoutedEventArgs e)
        {
            string binaryPositive = "12";
            string binaryNegative = "-3";
            int positive = Convert.ToInt32(binaryPositive);
            int negative = Convert.ToInt32(binaryNegative);
            int sum = positive + negative;
            MessageBox.Show($"Ответ =Сумма чисел: {Convert.ToString(sum, 2)}", "Системное сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
