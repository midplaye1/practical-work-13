﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page26.xaml
    /// </summary>
    public partial class Page26 : Page
    {
        public Page26()
        {
            InitializeComponent();
        }
        private void BtnTask26_Click(object sender, RoutedEventArgs e)
        {
            int[] array = { 101, 001, 1001, 10, 010 };
            int binaryNumber = Convert.ToInt32("1010", 2);
            for (int i = 0; i < array.Length; i++)
            {
                array[i] += binaryNumber;
            }
            MessageBox.Show($"Ответ =Массив после увеличения на 1010: {string.Join(", ", array)}", "Системное сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
