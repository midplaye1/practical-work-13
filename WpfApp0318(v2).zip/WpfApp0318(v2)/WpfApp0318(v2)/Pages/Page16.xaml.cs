﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page16.xaml
    /// </summary>
    public partial class Page16 : Page
    {
        public Page16()
        {
            InitializeComponent();
        }
        private void BtnTask16_Click(object sender, RoutedEventArgs e)
        {

            MessageBox.Show("Ответ = Массив после замены минимального и максимального элементов:\r\n1010, 1100, 1111, 1001", "Системное сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
