﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page5.xaml
    /// </summary>
    public partial class Page5 : Page
    {
        public Page5()
        {
            InitializeComponent();
        }
        private void BtnTask5_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string binaryInput = TextBoxBinaryNumber.Text;

                if (!IsBinaryFraction(binaryInput))
                {
                    MessageBox.Show("Ошибка: Введите двоичное число с дробной частью (например, 101.101).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                string[] parts = binaryInput.Split('.');
                string integerPart = parts.Length > 0 ? parts[0] : "0";
                string fractionalPart = parts.Length > 1 ? parts[1] : "0";

                double integerValue = ConvertBinaryToDecimal(integerPart);

                double fractionalValue = ConvertBinaryFractionToDecimal(fractionalPart);

                double decimalValue = integerValue + fractionalValue;

                MessageBox.Show($"Двоичное число: {binaryInput}\nДесятичное представление: {decimalValue}", "Результат", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool IsBinaryFraction(string input)
        {
            if (string.IsNullOrEmpty(input)) return false;
            string[] parts = input.Split('.');
            if (parts.Length > 2) return false;

            foreach (string part in parts)
            {
                foreach (char c in part)
                {
                    if (c != '0' && c != '1')
                        return false;
                }
            }
            return true;
        }

        private double ConvertBinaryToDecimal(string binary)
        {
            double decimalValue = 0;
            int length = binary.Length;
            for (int i = 0; i < length; i++)
            {
                if (binary[length - 1 - i] == '1')
                {
                    decimalValue += Math.Pow(2, i);
                }
            }
            return decimalValue;
        }

        private double ConvertBinaryFractionToDecimal(string binaryFraction)
        {
            double decimalValue = 0;
            for (int i = 0; i < binaryFraction.Length; i++)
            {
                if (binaryFraction[i] == '1')
                {
                    decimalValue += Math.Pow(2, -(i + 1));
                }
            }
            return decimalValue;
        }
    }
}
