﻿using ConsoleApp0318.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page19.xaml
    /// </summary>
    public partial class Page19 : Page
    {
        public Page19()
        {
            InitializeComponent();
        }
        private void BtnTask19_Click(object sender, RoutedEventArgs e)
        {
            int[] array19 = { 12, 21, 34, 22, 15, 4, 62, 2 };
            int n = array19.Length;
            if (n < 2)
            {
                Console.WriteLine("Не образуют");
                return;
            }

            int difference = array19[1] - array19[0];
            for (int i = 2; i < n; i++)
            {
                if (array19[i] - array19[i - 1] != difference)
                {
                    Console.WriteLine("Не образуют");
                    return;
                }
            }
            MessageBox.Show($"Ответ =Разность прогрессии: {difference}", "Системное сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
