﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page27.xaml
    /// </summary>
    public partial class Page27 : Page
    {
        public Page27()
        {
            InitializeComponent();
        }
        private void BtnTask27_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Ответ =Сумма исходного и сдвинутого массива: 30", "Системное сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int R = 9;
            int[] array = { 1, 5, 10, 15, 20 };
            int closestIndex = 0;
            double minDifference = Math.Abs(array[0] - R);

            for (int i = 1; i < array.Length; i++)
            {
                double difference = Math.Abs(array[i] - R);
                if (difference < minDifference)
                {
                    minDifference = difference;
                    closestIndex = i;
                }
            }

            MessageBox.Show($"Наиболее близкий элемент: {array[closestIndex]} на позиции {closestIndex}", "Системное сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
