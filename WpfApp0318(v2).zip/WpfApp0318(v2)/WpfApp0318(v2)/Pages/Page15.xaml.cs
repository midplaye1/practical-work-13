﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ConsoleApp0318;
using ConsoleApp0318.Classes;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page15.xaml
    /// </summary>
    public partial class Page15 : Page
    {
        public Page15()
        {
            InitializeComponent();
        }
        private void BtnTask15_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int size = int.Parse(TextBoxSize.Text);
                if (size <= 0)
                {
                    MessageBox.Show("Размер массива должен быть положительным числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                string[] binaryArray = InputArray(size);

                string[] sortedArray = SortArrayAscending(binaryArray);

                double average = CalculateAverage(sortedArray);

                MessageBox.Show($"Отсортированный массив по возрастанию:\n{string.Join(" ", sortedArray)}\n\nСреднее значение чисел в десятичной системе: {average}", "Результат", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private string[] InputArray(int size)
        {
            string[] array = new string[size];
            for (int i = 0; i < size; i++)
            {
                string input = Microsoft.VisualBasic.Interaction.InputBox($"Введите элемент {i + 1}:", "Ввод массива", "");
                while (!IsBinary(input))
                {
                    MessageBox.Show("Ошибка: Введите двоичное число (состоящее только из 0 и 1).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    input = Microsoft.VisualBasic.Interaction.InputBox($"Введите элемент {i + 1}:", "Ввод массива", "");
                }
                array[i] = input;
            }
            return array;
        }

        private bool IsBinary(string input)
        {
            foreach (char c in input)
            {
                if (c != '0' && c != '1')
                    return false;
            }
            return true;
        }

        private string[] SortArrayAscending(string[] array)
        {
            return array.OrderBy(x => Convert.ToInt32(x, 2)).ToArray();
        }

        private double CalculateAverage(string[] array)
        {
            int sum = array.Sum(x => Convert.ToInt32(x, 2));
            return (double)sum / array.Length;
        }
    }

}

