﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page30.xaml
    /// </summary>
    public partial class Page30 : Page
    {
        public Page30()
        {
            InitializeComponent();
        }
        private void BtnTask30_Click(object sender, RoutedEventArgs e)
        {
            int[] array = { 2, 9, 11 };
            string[] binaryArray = new string[array.Length];
            for (int i = 0; i < array.Length; i++)
            {
                binaryArray[i] = Convert.ToString(array[i], 2);
            }
            MessageBox.Show($"Ответ =Массив в двоичной системе: {string.Join(", ", binaryArray)}", "Системное сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
