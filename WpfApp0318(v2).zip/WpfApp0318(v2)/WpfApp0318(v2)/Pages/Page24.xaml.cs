﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page24.xaml
    /// </summary>
    public partial class Page24 : Page
    {
        public Page24()
        {
            InitializeComponent();
        }
        private void BtnTask24_Click(object sender, RoutedEventArgs e)
        {
            int[] array = { 101, 100, 1111, 01, 001, 111 };
            int n = array.Length;
            int[] shiftedArray = new int[n];
            for (int i = 0; i < n; i++)
            {
                shiftedArray[(i + 1) % n] = array[i];
            }
            MessageBox.Show($"Ответ =Массив после сдвига вправо: {string.Join(", ", shiftedArray)} ", "Системное сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
