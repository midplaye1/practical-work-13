﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page28.xaml
    /// </summary>
    public partial class Page28 : Page
    {
        public Page28()
        {
            InitializeComponent();
        }
        private void BtnTask28_Click(object sender, RoutedEventArgs e)
        {
            int D = 14;
            int[] array = { 1, 5, 10, 15, 20 };
            int farthestIndex = 0;
            double maxDifference = Math.Abs(array[0] - D);

            for (int i = 1; i < array.Length; i++)
            {
                double difference = Math.Abs(array[i] - D);
                if (difference > maxDifference)
                {
                    maxDifference = difference;
                    farthestIndex = i;
                }
            }
            MessageBox.Show($"Ответ =Наиболее удаленный элемент: {array[farthestIndex]} на позиции {farthestIndex}", "Системное сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
