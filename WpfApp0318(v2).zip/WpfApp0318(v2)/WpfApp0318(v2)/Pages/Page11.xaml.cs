﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page11.xaml
    /// </summary>
    public partial class Page11 : Page
    {
        public Page11()
        {
            InitializeComponent();
        }
        private void BtnTask11_Click(object sender, RoutedEventArgs e)
        {
            try
            {
            
                double[] array1 = ParseArray(TextBoxArray1.Text, 7);
                
                double[] array2 = ParseArray(TextBoxArray2.Text, 9);

                
                double[] mergedArray = MergeAndSortArrays(array1, array2);

                MessageBox.Show($"Результат: {string.Join(" ", mergedArray)}", "Результат", MessageBoxButton.OK, MessageBoxImage.Information); ;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private double[] ParseArray(string input, int expectedSize)
        {
            string[] parts = input.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length != expectedSize)
                throw new ArgumentException($"Ожидается {expectedSize} элементов.");

            double[] array = new double[expectedSize];
            for (int i = 0; i < expectedSize; i++)
            {
                if (!double.TryParse(parts[i], out array[i]))
                    throw new ArgumentException("Некорректный формат числа.");
            }
            return array;
        }

        private  double[] MergeAndSortArrays(double[] array1, double[] array2)
        {
            double[] mergedArray = array1.Concat(array2).ToArray();
            Array.Sort(mergedArray);
            Array.Reverse(mergedArray);
            return mergedArray;
        }

    }
}
