﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page13.xaml
    /// </summary>
    public partial class Page13 : Page
    {
        public Page13()
        {
            InitializeComponent();
        }
        private void BtnTask13_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string binaryNumber = TextBoxBinaryNumber.Text;

                if (!IsBinary(binaryNumber))
                {
                    MessageBox.Show("Ошибка: Введите двоичное число (состоящее только из 0 и 1).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                string shiftedNumber = CycleShiftLeft(binaryNumber, 2);


                int originalNumber = Convert.ToInt32(binaryNumber, 2);
                int shiftedNumberValue = Convert.ToInt32(shiftedNumber, 2);

                int difference = originalNumber - shiftedNumberValue;

                MessageBox.Show($"Исходное число: {binaryNumber} (в десятичной системе: {originalNumber})\n" +
                               $"Число после сдвига: {shiftedNumber} (в десятичной системе: {shiftedNumberValue})\n" +
                               $"Разность исходного и полученного числа: {difference}",
                               "Результат", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool IsBinary(string input)
        {
            foreach (char c in input)
            {
                if (c != '0' && c != '1')
                    return false;
            }
            return true;
        }

        private string CycleShiftLeft(string binaryNumber, int positions)
        {
            positions = positions % binaryNumber.Length;
            string shiftedPart = binaryNumber.Substring(0, positions);
            string remainingPart = binaryNumber.Substring(positions);
            return remainingPart + shiftedPart;
        }
    }
}

