﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page12.xaml
    /// </summary>
    public partial class Page12 : Page
    {
        public Page12()
        {
            InitializeComponent();
        }
        private void BtnTask12_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Ввод размера массива
                int size = int.Parse(TextBoxSize.Text);
                if (size <= 0)
                {
                    MessageBox.Show("Размер массива должен быть положительным числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                // Ввод массива
                int[] array = InputArray(size);

                // Поиск позиций одинаковых элементов
                int[] positions = FindDuplicatePositions(array);

                // Вывод результата в MessageBox
                if (positions[0] != -1 && positions[1] != -1)
                {
                    MessageBox.Show($"Два одинаковых элемента найдены на позициях: {positions[0] + 1} и {positions[1] + 1}", "Результат", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Два одинаковых элемента не найдены.", "Результат", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private int[] InputArray(int size)
        {
            int[] array = new int[size];
            for (int i = 0; i < size; i++)
            {
                string input = Microsoft.VisualBasic.Interaction.InputBox($"Введите элемент {i + 1}:", "Ввод массива", "");
                while (!int.TryParse(input, out array[i]))
                {
                    MessageBox.Show("Ошибка: Введите целое число.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    input = Microsoft.VisualBasic.Interaction.InputBox($"Введите элемент {i + 1}:", "Ввод массива", "");
                }
            }
            return array;
        }

        private int[] FindDuplicatePositions(int[] array)
        {
            int[] positions = new int[2] { -1, -1 };

            for (int i = 0; i < array.Length; i++)
            {
                for (int j = i + 1; j < array.Length; j++)
                {
                    if (array[i] == array[j])
                    {
                        positions[0] = i;
                        positions[1] = j;
                        return positions;
                    }
                }
            }
            return positions;
        }
    }
}
