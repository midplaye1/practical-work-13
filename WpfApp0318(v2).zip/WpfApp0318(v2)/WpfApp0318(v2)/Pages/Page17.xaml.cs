﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page17.xaml
    /// </summary>
    public partial class Page17 : Page
    {
        public Page17()
        {
            InitializeComponent();
        }
        private void BtnTask17_Click(object sender, RoutedEventArgs e)
        {
            int[] array17 = { 1, 2, 3, 4, 5 };
            int n = array17.Length;
            int[] shiftedArray = new int[n];
            for (int i = 0; i < n; i++)
            {
                shiftedArray[(i + 1) % n] = array17[i];
            }

            int sum = 0;
            for (int i = 0; i < n; i++)
            {
                sum += array17[i] + shiftedArray[i];
            }


            MessageBox.Show($"Ответ =Сумма исходного и сдвинутого массива:{sum}", "Системное сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
