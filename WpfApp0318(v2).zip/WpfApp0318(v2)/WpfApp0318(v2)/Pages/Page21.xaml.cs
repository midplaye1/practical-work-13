﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page21.xaml
    /// </summary>
    public partial class Page21 : Page
    {
        public Page21()
        {
            InitializeComponent();
        }
        private void BtnTask21_Click(object sender, RoutedEventArgs e)
        {
            int[] array = { 1, 2, 3, 2, 1, 4, 5, 6, 3, 2 };
            int count = 0;
            for (int i = 0; i < array.Length - 1; i++)
            {
                if (array[i] > array[i + 1])
                {
                    Console.WriteLine($"Индекс: {i}");
                    count++;
                }
            }
            MessageBox.Show($"Ответ =Количество таких чисел: {count}", "Системное сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
