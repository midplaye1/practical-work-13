﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page8.xaml
    /// </summary>
    public partial class Page8 : Page
    {
        public Page8()
        {
            InitializeComponent();
        }
        private void BtnTask8_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int size = 9;
                int[] originalArray = InputArray(size);

                MessageBox.Show($"Массив в десятичной системе счисления:\n{string.Join(" ", originalArray)}", "Результат", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private int[] InputArray(int size)
        {
            int[] array = new int[size];
            for (int i = 0; i < size; i++)
            {
                string input = Microsoft.VisualBasic.Interaction.InputBox($"Введите элемент {i + 1}:", "Ввод массива", "");
                while (!IsValidOctal(input))
                {
                    MessageBox.Show("Ошибка: Введите двузначное число в восьмеричной системе счисления (от 00 до 77).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    input = Microsoft.VisualBasic.Interaction.InputBox($"Введите элемент {i + 1}:", "Ввод массива", "");
                }
                array[i] = Convert.ToInt32(input, 8);
            }
            return array;
        }

        private bool IsValidOctal(string input)
        {
            if (input.Length != 2)
                return false;

            foreach (char c in input)
            {
                if (c < '0' || c > '7')
                    return false;
            }
            return true;
        }
    }
}
