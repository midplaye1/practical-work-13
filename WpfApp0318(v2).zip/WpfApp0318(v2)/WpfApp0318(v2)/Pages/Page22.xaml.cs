﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page22.xaml
    /// </summary>
    public partial class Page22 : Page
    {
        public Page22()
        {
            InitializeComponent();
        }
        private void BtnTask22_Click(object sender, RoutedEventArgs e)
        {
            int[] array = { 1, 2, 3, 2, 1, 4, 5, 6, 3, 2 };
            int lastIndex = -1;
            for (int i = 1; i < array.Length - 1; i++)
            {
                if (array[i - 1] < array[i] && array[i] < array[i + 1])
                {
                    lastIndex = i;
                }
            }

            if (lastIndex != -1)
            {
                MessageBox.Show($"Ответ =Номер последнего элемента: {lastIndex}", "Системное сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Таких нет", "Системное сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            
        }
    }
}
