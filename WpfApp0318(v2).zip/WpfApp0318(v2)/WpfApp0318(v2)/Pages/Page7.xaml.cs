﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page7.xaml
    /// </summary>
    public partial class Page7 : Page
    {
        public Page7()
        {
            InitializeComponent();
        }
        private void BtnTask7_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int size = 15;
                int[] originalArray = InputArray(size);
                int[] newArray = SwapDigitsInArray(originalArray);

                MessageBox.Show($"Исходный массив:\n{string.Join(" ", originalArray)}\n\nНовый массив с измененными разрядами:\n{string.Join(" ", newArray)}", "Результат", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private int[] InputArray(int size)
        {
            int[] array = new int[size];
            for (int i = 0; i < size; i++)
            {
                string input = Microsoft.VisualBasic.Interaction.InputBox($"Введите элемент {i + 1}:", "Ввод массива", "");
                while (true)
                {
                    if (int.TryParse(input, out int number) || number < 10 || number > 99)
                    {
                        array[i] = number;
                        break;
                    }
                    else
                    {
                        MessageBox.Show("Ошибка: Введите двузначное число (от 10 до 99).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }

                }              
            }
            return array;
        }

        private int[] SwapDigitsInArray(int[] array)
        {
            int[] newArray = new int[array.Length];
            for (int i = 0; i < array.Length; i++)
            {
                newArray[i] = SwapDigits(array[i]);
            }
            return newArray;
        }

        private int SwapDigits(int number)
        {
            int tens = number / 10;
            int units = number % 10;
            return units * 10 + tens;
        }
    }
}
