﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page9.xaml
    /// </summary>
    public partial class Page9 : Page
    {
        public Page9()
        {
            InitializeComponent();
        }
        private void BtnTask9_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int size = 7;
                int[] originalArray = InputArray(size);
                int[] newArray = ExtractHighDigits(originalArray);

                MessageBox.Show($"Исходный массив:\n{string.Join(" ", originalArray)}\n\nНовый массив из старших разрядов:\n{string.Join(" ", newArray)}", "Результат", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private int[] InputArray(int size)
        {
            int[] array = new int[size];
            for (int i = 0; i < size; i++)
            {
                int number;
                while (true)
                {
                    string input = Microsoft.VisualBasic.Interaction.InputBox($"Введите элемент {i + 1}:", "Ввод массива", "");
                    if (int.TryParse(input, out number) && number >= 10 && number <= 99)
                    {
                        array[i] = number;
                        break;
                    }
                    else
                    {
                        MessageBox.Show("Ошибка: Введите двузначное число (от 10 до 99).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            return array;
        }

        private int[] ExtractHighDigits(int[] array)
        {
            int[] newArray = new int[array.Length];
            for (int i = 0; i < array.Length; i++)
            {
                newArray[i] = array[i] / 10;
            }
            return newArray;
        }
    }
}
