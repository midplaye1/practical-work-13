﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WpfApp0318_v2_.Pages
{
    /// <summary>
    /// Логика взаимодействия для Page25.xaml
    /// </summary>
    public partial class Page25 : Page
    {
        public Page25()
        {
            InitializeComponent();
        }
        private void BtnTask25_Click(object sender, RoutedEventArgs e)
        {
            int[] array = { 101, 001, 1001, 10, 010 };
            int n = array.Length;
            int[] shiftedArray = new int[n];
            for (int i = 0; i < n; i++)
            {
                shiftedArray[i] = array[(i + 1) % n];
            }

            int sumBefore = array.Sum();
            int sumAfter = shiftedArray.Sum();
            MessageBox.Show($"Ответ =Сумма до сдвига: {sumBefore}\nСумма после сдвига: {sumAfter}", "Системное сообщение", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
